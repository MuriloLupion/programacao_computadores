import java.util.Scanner;

class exerc{

    public static void main(String[] args) {

        String nome;
        int idade;
        String genero;
        String corfavorita;
        String esporte;

        Scanner s = new Scanner(System.in);

        System.out.print("Informe seu nome: ");
        nome =s.next();
        System.out.println("Nome informado: "+nome);

        System.out.print("informe sua idade: ");
        idade =s.nextInt();
        System.out.println("Idade informada: "+idade);

        System.out.print("Informe seu gênero: ");
        genero =s.next();
        System.out.println("Gênero informado: "+genero);

        System.out.print("Informe sua cor favorita: ");
        corfavorita =s.next();
        System.out.println("Cor favorita Informada: "+corfavorita);

        System.out.print("Informe seu esporte favorito: ");
        esporte =s.next();
        System.out.println("esporte favorito: "+esporte);

        s.close();


    }
    
}