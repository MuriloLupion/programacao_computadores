import java.util.Scanner;

class exerc1{

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        double notaFinal;

        System.out.print("nota alcançada: ");
        notaFinal =s.nextDouble();
        if(notaFinal > 5) {
            System.out.println("aprovado");
        }
        else if(notaFinal < 4) {
            System.out.println("reprovado");
        }
        else{
            System.out.println("precisa fazer prova substitutiva");
        }

        s.close();

    }

}