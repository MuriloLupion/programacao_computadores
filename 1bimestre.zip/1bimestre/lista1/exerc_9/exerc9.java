import java.util.Scanner;

class exerc9{

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        int num1;

        double result;

        System.out.print("informe um valor inteiro: ");
        num1 =s.nextInt();

        if(num1 > 10 && num1 < 100) {
            result = Math.pow(num1, 2);
            System.out.println("o número está entre 10 e 100, elevado a 2 é: " + result);
        }
        else if(num1 > 100 || num1 < 10) {
            result = Math.sqrt(num1);
            System.out.println("o número é menor que 10 ou maior que 100, a raíz quadrada é : " + result);
        }
        else{
            System.out.println("o número é exatamente 10 ou 100, nenhuma operação foi realizada");
        }

        s.close();

    }
}
