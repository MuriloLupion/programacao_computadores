import java.util.Scanner;

class exerc5 {

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        int num;

        System.out.print("Informe um valor: ");
        num =s.nextInt();

        if(num % 2 == 0) {
            System.out.println("O número é par");
        }
        else{
            System.out.print("O número é impar");
        }

        s.close();
        
    }

}