import java.util.Scanner;

class exerc3 {
    
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        int num1;
        int num2;

        System.out.print("Informe o primeiro valor: ");
        num1 =s.nextInt();

        System.out.print("Informe o segundo valor: ");
        num2 =s.nextInt();

        int resultsoma = num1 + num2;
        int resultsub = num1 - num2;
        int resultdivi = num1 / num2;
        int resultmult = num1 * num2;

        System.out.println("Soma: "+resultsoma);

        System.out.println("Subtração; "+resultsub);

        System.out.println("Divisão: "+resultdivi);

        System.out.println("Multiplicação: "+resultmult);

        s.close();

    }

}
