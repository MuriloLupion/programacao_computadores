import java.util.Scanner;

class exerc6 {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        int num;

        System.out.print("Informe um valor: ");
        num =s.nextInt();

        int result2 = (int) Math.pow(num, 2);
        int result4 = (int) Math.pow(num, 4);
        int result6 = (int) Math.pow(num, 6);
        int result8 = (int) Math.pow(num, 8);
        int result10 = (int) Math.pow(num, 10);

        System.out.println("O número elevado a 2 é: "+result2);
        System.out.println("O número elevado a 4 é: "+result4);
        System.out.println("o número elevado a 6 é: "+result6);
        System.out.println("O número elevado a 8 é: "+result8);
        System.out.println("O número elevado a 10 é: "+result10);

        s.close();

    }

}
