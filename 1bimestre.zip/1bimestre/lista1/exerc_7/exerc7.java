import java.util.Scanner;

class exerc7{

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        int num1;
        int num2;

        System.out.print("informe o primeiro valor: ");
        num1 =s.nextInt();

        System.out.print("informe o segundo valor: ");
        num2 =s.nextInt();

        System.out.println(num1 + " > " + num2 + " ? " + (num1 > num2));
        System.out.println(num1 + " < " + num2 + " ? " + (num1 < num2));
        System.out.println(num1 + " == " + num2 + " ? " + (num1 == num2));
        System.out.println(num1 + " != " + num2 + " ? " + (num1 != num2));

        s.close();


    }
}
