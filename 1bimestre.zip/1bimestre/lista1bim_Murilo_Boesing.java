import java.util.Scanner;

class lista1bim_Murilo_Boesing{

    public static void main(String[] args){

        int exercicio=-1;
        Scanner s = new Scanner(System.in);
        
        do { 
            System.out.print("Informe qual o exercicio deseja executar: ");
            exercicio =s.nextInt();

            switch (exercicio) {
                case 1:
                    ex01();
                    break;
                case 2:
                    ex02();
                    break;
                    case 3:
                    ex03();
                    break;
                    case 4:
                    ex04();
                    break;
                    case 5:
                    ex05();
                    break;
                    case 6:
                    ex06();
                    break;
                    case 7:
                    ex07();
                    break;
                    case 8:
                    ex08();
                    break;
                    case 9:
                    ex09();
                    break;
                    case 10:
                    ex10();
                    break;
                    case 11:
                    ex11();
                    break;
                    case 12:
                    ex12();
                    break;
                    case 13:
                    ex13();
                    break;
                    case 14:
                    ex14();
                    break;
                    case 15:
                    ex15();
                    break;
                default:
                    throw new AssertionError();
            }

        } while (exercicio != 0);
        s.close();
        
    }    

        public static void ex01(){

            System.out.println("Exercicio 01: ");

        }

        public static void ex02(){

            System.out.println("Exercicio 02: ");

        }
        public static void ex03(){

            System.out.println("Exercicio 03: ");

        }
        public static void ex04(){

            System.out.println("Exercicio 04: ");

        }
        public static void ex05(){

            System.out.println("Exercicio 05: ");

        }
        public static void ex06(){

            System.out.println("Exercicio 06: ");

        }
        public static void ex07(){

            System.out.println("Exercicio 07: ");

        }
        public static void ex08(){

            System.out.println("Exercicio 08: ");

        }
        public static void ex09(){

            System.out.println("Exercicio 09: ");

        }
        public static void ex10(){

            System.out.println("Exercicio 10: ");

        }
        public static void ex11(){

            System.out.println("Exercicio 11: ");

        }
        public static void ex12(){

            System.out.println("Exercicio 12: ");

        }
        public static void ex13(){

            System.out.println("Exercicio 13: ");

        }
        public static void ex14(){

            System.out.println("Exercicio 14: ");

        }
        public static void ex15(){

            System.out.println("Exercicio 15: ");

        }
        
}