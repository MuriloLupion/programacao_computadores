import java.util.Scanner;

class exerc2{

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        int matric;
        double horas;
        double salario;
        String mes;
        double total;

        System.out.print("Informe o número da matricula: ");
        matric =s.nextInt();

        System.out.print("informe a quantidade de horas trabalhadas: ");
        horas =s.nextDouble();

        System.out.print("informe o valor que recebe por hora: ");
        salario =s.nextDouble();

        System.out.print("informe o mes que se refere as informações: ");
        mes =s.next();

        if(salario > 200){
            double contasalar = horas * salario;
            double extras = contasalar - 200;
            total = extras * 1.5;
        }
        else{total = horas * salario;}

        System.out.println("Matricula: "+matric);

        System.out.println("Salário: "+total);

        System.out.println("Mês: "+mes);

        s.close();

    }
}