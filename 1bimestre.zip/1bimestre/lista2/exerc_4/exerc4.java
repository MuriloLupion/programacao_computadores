import java.util.Scanner;

class exerc4{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        double altura;
        double peso;
        char sexo;
        double pesoideal;


        System.out.print("Informe a sua altura: ");
        altura =s.nextDouble();

        System.out.print("Informe seu peso: ");
        peso =s.nextDouble();

        System.out.print("Informe seu sexo com M ou F: ");
        sexo =s.next().charAt(0);

        if(sexo == 'M'){
            pesoideal = (72.7 * altura) - 58;
            if(peso<pesoideal){
                System.out.println("Você está abaixo do peso "+"O peso ideal é: "+pesoideal);
            }
            else if(peso>pesoideal){
            System.out.println("Você está acima do peso "+"O peso ideal é: "+pesoideal);
            }
            else{
                System.out.println("Você está no peso ideal");
            }
        }
        else if(sexo == 'F'){
            pesoideal = (62.1 * altura) - 44.7;
            if(peso<pesoideal){
                System.out.println("Você está abaixo do peso "+"O peso ideal é: "+pesoideal);
            }
            else if(peso>pesoideal){
            System.out.println("Você está acima do peso "+"O peso ideal é: "+pesoideal);
            }
            else{
                System.out.println("Você está no peso ideal");
            }
        }
        else{
            System.out.println("Informe uma resposta valida");
        }
        
    }
}