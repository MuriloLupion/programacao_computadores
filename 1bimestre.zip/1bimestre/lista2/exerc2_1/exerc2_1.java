import java.util.Scanner;

class exerc2_1{

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        double raio;

        System.out.print("Informe o raio: ");
        raio =s.nextDouble();

        double result = (4.0 / 3.0) * Math.PI * Math.pow (raio, 3);

        System.out.println("O volume da esfera é: "+result);

        s.close();
        
    }
}