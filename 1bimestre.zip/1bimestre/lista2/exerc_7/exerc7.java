import java.util.Scanner;

class exerc7{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        //o mês atual é, o próximo mês é, e o mês anterior é

        int mes;

        System.out.print("Informe um mês em formato númerico(ex: janeiro = 1): ");
        mes =s.nextInt();

        switch(mes){
            case 1:
            System.out.println("o mês atual é janeiro, o próximo mês é fevereiro,e o mês anterior é dezembro");
            break;
            case 2:
            System.out.println("o mês atual é fevereiro, o próximo mês é março, e o mês anterior é janeiro");
            case 3:
            System.out.println("o mês atual é março, o próximo mês é abril, e o mês anterior é fevereiro");
            break;
            case 4:
            System.out.println("o mês atual é abril, o próximo mês é maio, e o mês anterior é março");
            break;
            case 5:
            System.out.println("o mês atual é maio, o próximo mês é junho, e o mês anterior é abril");
            break;
            case 6:
            System.out.println("o mês atual é junho, o próximo mês é julho, e o mês anterior é maio");
            break;
            case 7:
            System.out.println("o mês atual é julho, o próximo mês é agosto, e o mês anterior é junho");
            break;
            case 8:
            System.out.println("o mês atual é agosto, o próximo mês é setembro, e o mês anterior é julho");
            break;
            case 9:
            System.out.println("o mês atual é setembro, o próximo mês é outubro, e o mês anterior é agosto");
            break;
            case 10:
            System.out.println("o mês atual é outubro, o próximo mês é novembro, e o mês anterior é setembro");
            break;
            case 11:
            System.out.println("o mês atual é novembro, o próximo mês é dezembro, e o mês anterior é outubro");
            break;
            case 12:
            System.out.println("o mês atual é dezembro, o próximo mês é janeiro, e o mês anterior é novembro");
            break;
            default:
            System.out.println("informe um valor válido");
        }

        s.close();

    }
}