import java.util.Scanner;

class exerc6{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        /*Faça um algoritmo que receba dois valores e um operador aritmético (+, -, /, * - adição, subtração, divisão e 
        multiplicação). Caso o símbolo seja outro, informe “Símbolo inválido”. Faça o cálculo conforme o operador
        informado e exiba a expressão e o resultado. */

        int vlr1;
        int vlr2;
        char operador;
        double calc = 0;
        boolean valido = true;

        System.out.print("Informe o primeiro valor: ");
        vlr1 =s.nextInt();

        System.out.print("Informe um operador aritmético(+, -, /, *): ");
        operador =s.next().charAt(0);

        System.out.print("Informe o segundo valor: ");
        vlr2 =s.nextInt();

        switch (operador){
            case '+':
            calc = vlr1 + vlr2;
            break;
            case '-':
            calc = vlr1 - vlr2;
            break;
            case '*':
            calc = vlr1 * vlr2;
            break;
            case '/':
            if(vlr2 !=0){
            calc = (double) vlr1 / vlr2;
            } else{
                System.out.println("Não é possível dividir por zero");
                valido = false;
            }
            break;
            default:
            System.out.println("Simbolo inválido");
            valido = false;
        }
        if (valido){

            System.out.println(vlr1+" "+operador+" "+vlr2+" "+"="+calc);
        }
        s.close();

    }
}