import java.util.Scanner;

class exerc10{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        int num1;
        int num2;

        System.out.print("Informe o primeiro número: ");
        num1 =s.nextInt();

        System.out.print("Informe o segundo número: ");
        num2 =s.nextInt();

        if(num1 > num2){
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        System.out.println("Valores entre "+num1+" e "+num2+": ");

        for(int i = num1 + 1; i < num2; i++){
        System.out.println(i);
        }
        s.close();

    }
}