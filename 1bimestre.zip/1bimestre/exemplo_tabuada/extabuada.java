import java.util.Scanner;

class extabuada{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        int num;

        System.out.print("Informe um número para calcular a tabuada: ");
        num =s.nextInt();

        System.out.println("\nTabuada so "+num+": ");
        for(int i = 1; i <= 10; i++){
            System.out.println(num+" X "+i+" - "+(num*i));
        }
        
    }
}