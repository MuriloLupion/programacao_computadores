class exemplo_1 {
    
    public static void main(String[] args){

        System.out.println("Ola Mundo! \nEsse é o meu primeiro programa");

        int idade = 19;
        double altura = 1.75;
        String nome = "Murilo";
        boolean estudante = true;
        char periodo = 'A';

        System.out.println("Nome:" + nome);
        System.out.println("Idade:"+idade);
        System.out.println("Altura"+altura);
        System.out.println("Estudante:"+estudante);
        System.out.println("Periodo:"+periodo);

    }

}