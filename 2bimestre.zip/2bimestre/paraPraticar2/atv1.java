import java.util.Scanner

class atv1{

    public static String divisao(double num2, double num2){

        
    }
}

/*Crie uma função chamada divisão,
com retorno real e que receba dois valores por parâmetros.
Se o divisor for igual a 0, ela deve retornar 0.
Se não, deve retornar a divisão entre eles. 
 */