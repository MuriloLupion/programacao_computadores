import java.util.Scanner;

class atv1{

    public static String divisao(double num1, double num2){

        if(num2==0){
            return "O resultado é "+0;
        }
        else{
            return "O resultado é "+num1 / num2;
        }

    }

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        double vlr1, vlr2;

        System.out.print("Informe o número a ser dividido: ");
        vlr1=s.nextDouble();

        System.out.print("Informe o divisor: ");
        vlr2=s.nextDouble();

       System.out.println(divisao(vlr1, vlr2));
        
       s.close();
    }
}

/*Crie uma função chamada divisão,
com retorno real e que receba dois valores por parâmetros.
Se o divisor for igual a 0, ela deve retornar 0.
Se não, deve retornar a divisão entre eles. 
 */