import java.util.Arrays;

class atv4{

    public static int[] ordena_vetor(int[] nums){

        Arrays.sort(nums);
        return nums;
        
    }

    public static void main(String[] args) {
        
        int[] vlrs={50, 10, 30, 20, 40};

        int[] ordenado = ordena_vetor(vlrs);

        System.out.print("Vetor em ordem crescente: ");
        for(int num1 : ordenado){
            System.out.print(num1+" ");
        }
        
    }
}

/*Crie uma função chama ordena_vetor que receba um vetor de inteiros e retorne um vetor de inteiros em ordem crecente */