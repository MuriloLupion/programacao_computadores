class atv3{

    public static void imprime_vetor_string(String[] plvr){

        System.out.print("Elementos do vetor: ");
        for(int i=0; i<plvr.length; i++){
            System.out.print(plvr[i]+" ");
        }
        System.out.println();

    }
    public static void main(String[] args) {
     
        String[] frutas={"Maçã", "Banana", "Laranja", "Uva", "Pêra"};

        imprime_vetor_string(frutas);
    }
}

/*Crie uma função chamada imprime_vetor_string que receba uma matriz de String por parâmetro e imprima os valores em tela. 
 */