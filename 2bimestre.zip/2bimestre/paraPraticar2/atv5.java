class atv5{

}

/*Crie uma função que receba uma matriz e escreva na tela a soma de cada linha da mesma. */