class atv2{

    public static void imprime_vetor_int(int[] num1){

    System.out.print("Elementos do vetor: ");
    for(int i=0; i<num1.length; i++){
        System.out.print(num1[i]+" ");
                
    }
    System.out.println();
    
}

    public static void main(String[] args){
        
        int[] vlr1 = {10, 20 , 30, 40, 50};

        imprime_vetor_int(vlr1);

    }

}

/*Crie uma função chamada imprime_vetor_int que receba um vetor de inteiro por parâmetro e faça a impressão na tela do vetor.  */