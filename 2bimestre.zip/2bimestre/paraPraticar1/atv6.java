import java.util.Scanner;

class atv6{

    public static String menor(int num1, int num2){

        if(num1<num2){
            return "O número menor é: "+num1;
        }
        else if(num1>num2){
            return "O número menor é: "+num2;
        }
        else{
            return "Os números são iguais!";
        }
    }

    public static void main(String[] args){

        int vlr1, vlr2;

        Scanner s = new Scanner(System.in);

        System.out.print("Informe o primeiro número: ");
        vlr1=s.nextInt();

        System.out.print("Informe o segundo número: ");
        vlr2=s.nextInt();

        System.out.println(menor(vlr1, vlr2));

        s.close();

    }
}

//Crie uma função menor que receba dois números inteiros por par}ametro e retorno o menor deles.
