import java.util.Scanner;

class atv5{

    public static String maior(int num1, int num2){

        if(num1>num2){
            return "O número maior é: "+num1;
        }
        else if(num1<num2){
            return "O número maior é: "+num2;
        }
        else{
            return "Os números são iguais";
        }
    }

    public static void main(String[] args){

        int vlr1;
        int vlr2;

        Scanner s = new Scanner(System.in);

        System.out.print("Informe o primeiro número: ");
        vlr1=s.nextInt();

        System.out.print("Informe o segundo número: ");
        vlr2=s.nextInt();

        System.out.println(maior(vlr1, vlr2));

        s.close();

    }
}

//Crie uma função maior que receba dois número inteiros por parâmetro e retorne o maior deles.