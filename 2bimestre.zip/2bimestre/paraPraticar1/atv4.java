import java.util.Random;

class atv4{

    public static String par_impar(int num1){

            if(num1%2==0){
                return "O número"+num1+" é par";
            }
            else{
                return "O número"+num1+" é impar";
            }
    }

    public static void main(String[] args){

        Random random = new Random();

        int numero[] = new int[20];

        for(int i=0; i<numero.length; i++){
            numero[i]=random.nextInt(1000);
        }

        System.out.println("\nNúmeros informados: ");
        
        for(int i=0; i<numero.length; i++){
            System.out.println("Posição["+i+"]= "+par_impar(numero[i]));
        }
    }
}


/*Crie uma função chamada par_impar() que receba um número inteiro
e retorne um texto informando se ele é par ou ímpar. Depois,
no corpo do programa crie um vetor de 20 posições e preencha-o com números aleatórios.
Depois, use a função par_impar() para verificar e exibir cada posição, número e se ele é par ou ímpar. */