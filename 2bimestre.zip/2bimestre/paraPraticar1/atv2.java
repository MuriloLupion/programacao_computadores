import java.util.Scanner;

class atv2{

    public static String solicita_texto() {

        Scanner s = new Scanner(System.in);

        String palavra="";

        while(palavra.length() < 5){
            System.out.print("Informe uma palavra: ");
            palavra =s.next();
            if(palavra.length()<5){
                System.out.println("Palavra muito pequena");
            }
        }

        return palavra;
        
    }

    public static void main(String[] args){

        String[] frutas = new String[5];

        for (int i = 0; i < frutas.length; i++) {
            frutas[i] = solicita_texto();
        }

        System.out.println("\nFrutas informadas:");
        for (int i = 0; i < frutas.length; i++) {
            System.out.println((i + 1) + ": " + frutas[i]);
        }
    }
}

/*Crie uma função chamada solicita_texto que peça ao usuário uma String e
retorne o valor informado desde que tenha mais do que 5 caracteres.
Caso o texto tenha menos caracteres, informe “Palavra muito pequena”.
Depois, no corpo do programa crie um vetor de 5 posições de Strings chamado
frutas e use a função para preenchê-lo.*/