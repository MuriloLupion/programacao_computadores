import java.util.Scanner;

class atv7{

    public static String resultado_aluno(int num1, int num2, int num3){

        int menor = Math.min(num1, Math.min(num2, num3));
        int soma = num1+num2+num3-menor;
        
        return "Sua nota é: "+soma;

    }

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        int vlr1, vlr2, vlr3;

        System.out.print("Informe a nota do 1° bimeste: ");
        vlr1=s.nextInt();

        System.out.print("Informe a nota do 2° bimeste: ");
        vlr2=s.nextInt();

        System.out.print("Informe a nota da substitutiva: ");
        vlr3=s.nextInt();

        System.out.println(resultado_aluno(vlr1, vlr2, vlr3));
    }
}

/*Crie uma função resultado_aluno que receba 3 notas de um aluno
(nota 1º prova, nota 2ª prova e nota prova substitutiva) e retorne o resultado.
Lembrando que a média final deve ser calculada entre as duas maiores notas. */