import java.util.Scanner;

class atv1{

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        double vlr1, vlr2;

        System.out.print("Informe o peirmeiro valor: ");
        vlr1 =s.nextDouble();

        System.out.print("Informe o segundo valor: ");
        vlr2 =s.nextDouble();

        System.out.println("Resultado: "+calculo(vlr1,vlr2));

    }
    /*Crie uma função chamada calculo, com retorno double/real e que receba dois parâmetros double/real.
    Quando num1 for maior que num2, ela deve retornar a multiplicação dos dois.
    Quando o num1 for menor que num2, deve-se retornar a divisão entre os dois.
    Quando eles forem iguais, deve-se retornar a soma deles. */

    public static double calculo(double num1, double num2){

        if(num1>num2){
            return num1*num2;
        } else if(num2>num1){
            return num1 / num2;
        } else{
            return num1 + num2;
        }

    }
}