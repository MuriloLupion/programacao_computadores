import java.util.Scanner;

class atv3{

    public static int numeros(Scanner s) {

        int num1;

        do {
            System.out.print("Informe um número entre 0 e 1000: ");
            num1 = s.nextInt();
    
            if (num1 < 0 || num1 > 1000) {
                System.out.println("Número inválido");
            }
        } while (num1 < 0 || num1 > 1000);
    
        return num1;
    }
    

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        int teste[] = new int[10];

        for(int i = 0; i < teste.length; i++){
            System.out.println("\nPosição ["+1+"]: ");
            teste[i] = numeros(s);
        }
        
        System.out.println("\nNúmeros informados: ");

        for(int i = 0; i < teste.length; i++){
            System.out.println("Posição ["+i+"] = " + teste[i]);
        }

    }

}

/*Crie uma função que peça ao usuário um número e retorne o número informado.
Ela deve validar se ele é maior que 0 e menor que 1.000. Caso não seja, informe número inválido.
No corpo do programa, crie um vetor de 10 posições de inteiros e para preencher o vetor,
chame a função criada anteriormente. No final, exiba os números informados pelo usuário. */