import java.util.Scanner;

class atv1{

    public static String notas(double num1, double num2, double num3, double num4){

        double total = num1 + num2 + num3 + num4;

        double media = total / 4;

        return "sua nota é: "+media;
    }

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        double vlr1, vlr2, vlr3, vlr4;

        System.out.print("Informe sua primeira nota: ");
        vlr1=s.nextDouble();

        System.out.print("Informe sua segunda nota: ");
        vlr2=s.nextDouble();

        System.out.print("Informe sua terceira nota: ");
        vlr3=s.nextDouble();

        System.out.print("Informe sua quarta nota: ");
        vlr4=s.nextDouble();

        System.out.println(notas(vlr1, vlr2, vlr3, vlr4));
        
        s.close();
    }
}

/*Declare um vetor do tipo real, com 4 posições. Peça as notas dos 4 bimestres de um aluno e no final calcule a média. */