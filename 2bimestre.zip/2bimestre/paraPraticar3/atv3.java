import java.util.Arrays;
import java.util.Scanner;

class atv3{

    public static void main(String[] args){

        String nome[]= new String[5];

        usuarios(nome);
    }

    public static void usuarios(String nome[]){

        Scanner s = new Scanner(System.in);

        for(int i=0;i<nome.length;i++){
            nome[i]=s.next();
        }

        Arrays.sort(nome);

        System.out.println(nome[]);
        
        s.close();

    }
}

/*Declare um vetor de texto/cadeia com 5 elementos. Solicite 5 nomes ao usuário e salve no vetor. Depois imprima os nomes informados na ordem informada. */