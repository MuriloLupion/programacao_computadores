import java.util.Arrays;
import java.util.Scanner;


class atv2{

    public static void main(String[] args){

        double num1[]=new double[10];

        notas(num1);

    }

    public static void notas(double num1[]){

        Scanner s = new Scanner(System.in);

        for(int i=0; i<num1.length;i++){
            System.out.print("Informe sua nota: ");
            num1[i]=s.nextDouble();
        }

        double total=0;

        Arrays.sort(num1);

        System.out.println("Menor Nota: "+num1[0]);
        System.out.println("Maior Nota: "+num1[9]);

        for(int i=0;i<num1.length;i++){
            total += num1[i];
        }
        System.out.println("Media: "+total/10);

        s.close();

       
    }
}

/*Declare um vetor do tipo real de 10 posições. Peça as notas de 10 alunos da disciplina de algoritmos. Insira no vetor e depois exiba a média da sala, a menor e a maior nota. */