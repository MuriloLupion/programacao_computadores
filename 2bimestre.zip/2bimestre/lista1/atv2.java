import java.util.Scanner;

class atv2{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        String[] frutas = new String[5];

    }

    public static String solicita_texto() {

        Scanner s = new Scanner(System.in);

        String texto;

        System.out.print("Informe uma palavra com mais de 5 caracters: ");
        texto =s.next();

        if(texto.length()<=5){
            return texto;
        }
        else{
            return "Palavra muito pequena";
        }

    }
}

/*Crie uma função chamada solicita_texto que peça ao usuário uma String e
retorne o valor informado desde que tenha mais do que 5 caracteres.
Caso o texto tenha menos caracteres, informe “Palavra muito pequena”.
Depois, no corpo do programa crie um vetor de 5 posições de Strings chamado
frutas e use a função para preenchê-lo.*/